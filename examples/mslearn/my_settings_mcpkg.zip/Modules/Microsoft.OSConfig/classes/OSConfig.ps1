# Copyright (c) Microsoft Corporation. All rights reserved.

function Get-ServerType() {
    try {
        $Value = Get-ItemPropertyValue -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters" -Name "SysvolReady"
        if (-not [String]::IsNullOrWhiteSpace($Value)) {
            return "Domain Controller"
        }
    } catch {
        # Ignored.
    }

    try {
        $Value = Get-ItemPropertyValue -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -Name "Domain"
        if (-not [String]::IsNullOrWhiteSpace($Value)) {
            return "Member Server"
        }
    } catch {
        # Ignored.
    }

    return "Workgroup Member"
}

function Get-EnvironmentType {
    $Properties = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion"

    if ($Properties.InstallationType -match "Server") {
        if ($Properties.EditionId -eq "ServerAzureStackHCICor") {
            $InstallationType = "AzureLocal"

            if ($Properties.DisplayVersion -eq "24H2") {
                $Version = "24H2"
            } elseif ($Properties.DisplayVersion -eq "23H2") {
                $Version = "23H2"
            } else {
                return
            }
        } else {
            $InstallationType = "WindowsServer"

            # We need to have the necessary update for Windows Server 2022 and Windows Server 23H2
            # but not for Windows Server 2025. We can use the UBR (Update Build Revision) to
            # determine the version.

            if ($Properties.DisplayVersion -eq "24H2") {
                $Version = "2025"
            } elseif (($Properties.DisplayVersion -eq "23H2") -and ($Properties.UBR -ge 1369)) {
                $Version = "2022"
            } elseif (($Properties.DisplayVersion -eq "21H2") -and ($Properties.UBR -ge 3091)) {
                $Version = "2022"
            } else {
                return
            }
        }
    } else {
        return
    }

    $Role = (Get-ServerType) -replace " ", ""

    "$InstallationType\$Version\$Role"
}

function ConvertFrom-Expression($Expression) {
    if ($Expression -isnot [String] -or [String]::IsNullOrWhiteSpace($Expression)) {
        throw [InvalidValueException]::new($Strings.ErrorInvalidExpression -f $Expression)
    }

    $InQuotes = $False
    $ProcessedExpression = $Expression.Clone()

    for ($i = 0; $i -lt $Expression.Length; $i++) {
        if ($Expression[$i] -eq '"') {
            $InQuotes = -not $InQuotes
            continue
        }

        if ($InQuotes) {
            continue
        }

        if ($Expression[$i] -eq ";") {
            $ProcessedExpression = $ProcessedExpression.Remove($i, 1).Insert($i, "`n")
        }
    }

    try {
        $Result = @($ProcessedExpression | ConvertFrom-Csv -Header @("Name", "Value") -Delimiter ":")

        if (($Result.Count -eq 1) -and (-not $Result.Value)) {
            $Result[0].Value = $Result[0].Name
            $Result[0].Name = "*"
        }

        , $Result
    } catch {
        throw [InvalidValueException]::new($Strings.ErrorInvalidExpression -f $Expression)
    }
}

function Find-Rule($Name, $Rules) {
    foreach ($Rule in $Rules) {
        $InclusionRule = -not $Rule.Name.StartsWith("!")

        if ($InclusionRule -and ($Name -like $Rule.Name)) {
            return $Rule
        }

        if (-not $InclusionRule -and ($Name -like $Rule.Name.Substring(1))) {
            return $null
        }
    }
}

class OSConfigReason {
    [DscProperty()]
    [String] $Code

    [DscProperty()]
    [String] $Phrase

    OSConfigReason() { }

    OSConfigReason([String] $RuleId, [String] $Severity, [Bool] $IsCompliant, [String] $Reason) {
        $Status = if ($IsCompliant) { 'BaselineSettingCompliant' } else { 'BaselineSettingNotCompliant' }

        if ($RuleId) {
            $Status = "$Status`:$RuleId"
        }

        $this.Code = $Status

        if (-not [String]::IsNullOrWhiteSpace($Severity)) {
            $this.Phrase = "[$Severity] $Reason"
        } else {
            $this.Phrase = $Reason
        }
    }
}

[DscResource()]
class OSConfig {
    [DscProperty()]
    [String] $RuleId

    [DscProperty()]
    [String] $Severity

    [DscProperty()]
    [String] $CorrelationGroup

    [DscProperty(Key)]
    [String] $Name

    [DscProperty(Key)]
    [String] $Type

    [DscProperty(Key)]
    [String] $Properties

    [DscProperty()]
    [String] $Value

    [DscProperty()]
    [String] $ValueType

    [DscProperty()]
    [String] $ValueName = 'value'

    [DscProperty()]
    [String] $Compliance

    [DscProperty()]
    [String] $Template

    [DscProperty()]
    [String] $RoleFilter

    [DscProperty()]
    [String] $VersionFilter

    [DscProperty(NotConfigurable)]
    [OSConfigReason[]] $Reasons

    hidden [Bool] $IsCompliant = $True

    [OSConfig] Get() {
        $CurrentState = [OSConfig]::new()

        $CurrentState.RuleId = $this.RuleId
        $CurrentState.Severity = $this.Severity
        $CurrentState.Name = $this.Name
        $CurrentState.Type = $this.Type
        $CurrentState.Properties = $this.Properties
        $CurrentState.Value = $this.Value
        $CurrentState.Compliance = $this.Compliance
        $CurrentState.RoleFilter = $this.RoleFilter
        $CurrentState.VersionFilter = $this.VersionFilter
        $CurrentState.Reasons = @()

        $env:CorrelationGroup = $this.CorrelationGroup

        try {
            $ErrorActionPreference = 'Stop'

            if (-not $this.IsApplicable()) {
                $CurrentState.IsCompliant = $True
                $CurrentState.Reasons += [OSConfigReason]::new($this.RuleId, $null, $CurrentState.IsCompliant, 'Not applicable')
                return $CurrentState
            }

            $ActualValue = $this.GetActualValue()

            $Resource = @{
                Name       = $this.Name
                Type       = 'Microsoft.OSConfig/Test'
                Properties = @{
                    'resource' = @{
                        'name'       = $this.Name
                        'type'       = $this.Type
                        'properties' = $this.Properties | ConvertFrom-Json
                    }
                    'schema'   = $this.GetSchema($ActualValue)
                    'template' = $this.GetTemplate($ActualValue)
                }
            }

            $Output = Invoke-Native exec resource --mode get --name $Resource.Name --type $Resource.Type --properties ($Resource.Properties | ConvertTo-Json -Compress)

            $CurrentState.IsCompliant = $Output.Properties.Compliance.Status -eq 'compliant'
            $CurrentState.Reasons += [OSConfigReason]::new($this.RuleId, $CurrentState.Severity, $CurrentState.IsCompliant, $Output.Properties.Compliance.Reason)
        } catch {
            $CurrentState.IsCompliant = $False
            $CurrentState.Reasons += [OSConfigReason]::new($this.RuleId, $CurrentState.Severity, $CurrentState.IsCompliant, "$_")
            Write-Verbose "Error: $_"
        }

        return $CurrentState
    }

    [Bool] Test() {
        try {
            return $this.Get().IsCompliant
        } catch {
            Write-Verbose "Error: $_"
        }

        return $False
    }

    [Void] Set() {
        try {
            $env:CorrelationGroup = $this.CorrelationGroup

            if (-not $this.CorrelationGroup) {
                throw "No correlation group specified."
            }

            $ResourceProperties = $this.Properties | ConvertFrom-Json

            if ($this.ValueName) {
                $ResourceProperties | Add-Member -MemberType NoteProperty -Name $this.ValueName -Value $this.GetActualValue()
            }

            Invoke-Native exec resource --mode set --name $this.Name --type $this.type --properties $ResourceProperties
        } catch {
            Write-Verbose "Error: $_"
        }
    }

    [Bool] IsApplicable() {
        if (-not [String]::IsNullOrWhiteSpace($this.RoleFilter)) {
            $CurrentRole = Get-ServerType
            $AllowedRoles = $this.RoleFilter -split ',' | ForEach-Object { $_.Trim() }

            if ($AllowedRoles -notcontains $CurrentRole) {
                return $False
            }
        }

        if (-not [String]::IsNullOrWhiteSpace($this.VersionFilter)) {
            $CurrentVersion = Get-WindowsServerVersion

            if (-not $CurrentVersion) {
                return $False
            }

            $AllowedVersions = $this.VersionFilter -split ',' | ForEach-Object { $_.Trim() }

            if ($AllowedVersions -notcontains $CurrentVersion) {
                return $False
            }
        }

        if (-not $this.Compliance) {
            $Rules = if (-not [String]::IsNullOrWhiteSpace($this.Value)) {
                ConvertFrom-Expression -Expression $this.Value
            }

            $EnvironmentType = Get-EnvironmentType
            $Rule = Find-Rule -Name $EnvironmentType -Rules $Rules

            if ($Rules -and (-not $Rule)) {
                return $False
            }
        }

        return $True
    }

    [PSCustomObject] GetSchema([PSCustomObject] $ActualValue) {
        if ($this.Compliance) {
            return ConvertFrom-Json -InputObject $this.Compliance
        }

        if ($null -eq $ActualValue) {
            return @{ 'type' = 'null' }
        }

        switch ($this.ValueType) {
            'string' {
                return @{ 'type' = 'string'; 'const' = $ActualValue }
            }
            'string[]' {
                return @{
                    'type'  = 'array'
                    'items' = @{
                        'type'        = 'string'
                        'enum'        = $ActualValue
                        'minItems'    = $ActualValue.Count
                        'maxItems'    = $ActualValue.Count
                        'uniqueItems' = $True
                    }
                }
            }
            'integer' {
                return @{ 'type' = 'integer'; 'const' = $ActualValue }
            }
            'boolean' {
                return @{ 'type' = 'boolean'; 'const' = $ActualValue }
            }
        }

        return @{ 'const' = $ActualValue }
    }

    [String] GetTemplate([PSCustomObject] $ActualValue) {
        if ($this.Template) {
            return $this.Template
        }

        if ($null -eq $ActualValue) {
            return "The value {value} must be (null)"
        }

        return "The value {value} must be $(ConvertTo-Json -InputObject $ActualValue -Compress)."
    }

    [PSCustomObject] GetActualValue() {
        $Rules = if (-not [String]::IsNullOrWhiteSpace($this.Value)) {
            ConvertFrom-Expression -Expression $this.Value
        }

        $EnvironmentType = Get-EnvironmentType
        $Rule = Find-Rule -Name $EnvironmentType -Rules $Rules

        $StringValue = if ($null -ne $Rule) { $Rule.Value } else { $this.Value }

        if ($null -eq $StringValue) {
            return $null
        }

        try {
            switch ($this.ValueType) {
                'string' {
                    return $StringValue
                }
                'integer' {
                    return [Int64]::Parse($StringValue)
                }
                'boolean' {
                    if ([Int32]::TryParse($StringValue, [ref]$null)) {
                        return [Boolean]::Parse(([Int32]$StringValue -ne 0).ToString())
                    } else {
                        return [Boolean]::Parse($StringValue)
                    }
                }
                'string[]' {
                    if ([String]::IsNullOrWhiteSpace($StringValue)) {
                        return @()
                    } else {
                        return @($StringValue -split ',' | ForEach-Object { $_.Trim() })
                    }
                }
            }
        } catch {
            throw "Unable to convert value '$StringValue' to type '$($this.ValueType)'"
        }

        return $StringValue
    }
}

# SIG # Begin signature block
# MIIoKgYJKoZIhvcNAQcCoIIoGzCCKBcCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAJWMjgVQ9Bvu56
# rQN0LDS9igJzfAmONfeqaTSEfmbMU6CCDXYwggX0MIID3KADAgECAhMzAAAEhV6Z
# 7A5ZL83XAAAAAASFMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjUwNjE5MTgyMTM3WhcNMjYwNjE3MTgyMTM3WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDASkh1cpvuUqfbqxele7LCSHEamVNBfFE4uY1FkGsAdUF/vnjpE1dnAD9vMOqy
# 5ZO49ILhP4jiP/P2Pn9ao+5TDtKmcQ+pZdzbG7t43yRXJC3nXvTGQroodPi9USQi
# 9rI+0gwuXRKBII7L+k3kMkKLmFrsWUjzgXVCLYa6ZH7BCALAcJWZTwWPoiT4HpqQ
# hJcYLB7pfetAVCeBEVZD8itKQ6QA5/LQR+9X6dlSj4Vxta4JnpxvgSrkjXCz+tlJ
# 67ABZ551lw23RWU1uyfgCfEFhBfiyPR2WSjskPl9ap6qrf8fNQ1sGYun2p4JdXxe
# UAKf1hVa/3TQXjvPTiRXCnJPAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUuCZyGiCuLYE0aU7j5TFqY05kko0w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwNTM1OTAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBACjmqAp2Ci4sTHZci+qk
# tEAKsFk5HNVGKyWR2rFGXsd7cggZ04H5U4SV0fAL6fOE9dLvt4I7HBHLhpGdE5Uj
# Ly4NxLTG2bDAkeAVmxmd2uKWVGKym1aarDxXfv3GCN4mRX+Pn4c+py3S/6Kkt5eS
# DAIIsrzKw3Kh2SW1hCwXX/k1v4b+NH1Fjl+i/xPJspXCFuZB4aC5FLT5fgbRKqns
# WeAdn8DsrYQhT3QXLt6Nv3/dMzv7G/Cdpbdcoul8FYl+t3dmXM+SIClC3l2ae0wO
# lNrQ42yQEycuPU5OoqLT85jsZ7+4CaScfFINlO7l7Y7r/xauqHbSPQ1r3oIC+e71
# 5s2G3ClZa3y99aYx2lnXYe1srcrIx8NAXTViiypXVn9ZGmEkfNcfDiqGQwkml5z9
# nm3pWiBZ69adaBBbAFEjyJG4y0a76bel/4sDCVvaZzLM3TFbxVO9BQrjZRtbJZbk
# C3XArpLqZSfx53SuYdddxPX8pvcqFuEu8wcUeD05t9xNbJ4TtdAECJlEi0vvBxlm
# M5tzFXy2qZeqPMXHSQYqPgZ9jvScZ6NwznFD0+33kbzyhOSz/WuGbAu4cHZG8gKn
# lQVT4uA2Diex9DMs2WHiokNknYlLoUeWXW1QrJLpqO82TLyKTbBM/oZHAdIc0kzo
# STro9b3+vjn2809D0+SOOCVZMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGgowghoGAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAASFXpnsDlkvzdcAAAAABIUwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIKimvUY/FFioUvubH7qh/LA9
# sFHtRQ9hTExMGmDepEvZMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAB8ztbD4/HRKMRn6W5fAFZyQ4/6Rd6k4Izuft/o+Rd+a/QpiqqKtf9C83
# EloC0VAjce6yD1gl60ZJBBPYA3V0TB4QtYvStJBbakudU5zFuPT81R5eEjBEcOE6
# etgjjirHRUQeQHYtZlfVmxa3mbNx0j33/8VS+HLrasy6mJRIsY+A0DZZvajFgVSD
# aijXQ3femcbU3LRKHccAnwYI8gjl5UQnxSU+4dC5X1zqYFyh1dvP8PxJSZPgSctO
# DWr03ePIKwlfhtqm/zrnJMMowN8L7IBatFSqGl72J034SuHbD5rhp3QPuwyPdjCm
# wacNd0G99IsOWmCvYYAVs4OQNiEA/qGCF5QwgheQBgorBgEEAYI3AwMBMYIXgDCC
# F3wGCSqGSIb3DQEHAqCCF20wghdpAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFSBgsq
# hkiG9w0BCRABBKCCAUEEggE9MIIBOQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCCfVqBD+DEl2Y2Kkr0nOKa9G5Rm2yQLa3BSheP0SdMgYAIGaWj3ffSI
# GBMyMDI2MDEyMTE4Mjg0Ni4zMjRaMASAAgH0oIHRpIHOMIHLMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1l
# cmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046OTIwMC0w
# NUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# ghHqMIIHIDCCBQigAwIBAgITMwAAAgkIB+D5XIzmVQABAAACCTANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yNTAxMzAxOTQy
# NTVaFw0yNjA0MjIxOTQyNTVaMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046OTIwMC0wNUUwLUQ5NDcxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQDClEow9y4M3f1S9z1xtNEETwWL1vEiiw0oD7SXEdv4
# sdP0xsVyidv6I2rmEl8PYs9LcZjzsWOHI7dQkRL28GP3CXcvY0Zq6nWsHY2QamCZ
# FLF2IlRH6BHx2RkN7ZRDKms7BOo4IGBRlCMkUv9N9/twOzAkpWNsM3b/BQxcwhVg
# sQqtQ8NEPUuiR+GV5rdQHUT4pjihZTkJwraliz0ZbYpUTH5Oki3d3Bpx9qiPriB6
# hhNfGPjl0PIp23D579rpW6ZmPqPT8j12KX7ySZwNuxs3PYvF/w13GsRXkzIbIyLK
# EPzj9lzmmrF2wjvvUrx9AZw7GLSXk28Dn1XSf62hbkFuUGwPFLp3EbRqIVmBZ42w
# cz5mSIICy3Qs/hwhEYhUndnABgNpD5avALOV7sUfJrHDZXX6f9ggbjIA6j2nhSAS
# Iql8F5LsKBw0RPtDuy3j2CPxtTmZozbLK8TMtxDiMCgxTpfg5iYUvyhV4aqaDLwR
# BsoBRhO/+hwybKnYwXxKeeOrsOwQLnaOE5BmFJYWBOFz3d88LBK9QRBgdEH5CLVh
# 7wkgMIeh96cH5+H0xEvmg6t7uztlXX2SV7xdUYPxA3vjjV3EkV7abSHD5HHQZTrd
# 3FqsD/VOYACUVBPrxF+kUrZGXxYInZTprYMYEq6UIG1DT4pCVP9DcaCLGIOYEJ1g
# 0wIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFEmL6NHEXTjlvfAvQM21dzMWk8rSMB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwDgYDVR0PAQH/BAQD
# AgeAMA0GCSqGSIb3DQEBCwUAA4ICAQBcXnxvODwk4h/jbUBsnFlFtrSuBBZb7wSZ
# fa5lKRMTNfNlmaAC4bd7Wo0I5hMxsEJUyupHwh4kD5qkRZczIc0jIABQQ1xDUBa+
# WTxrp/UAqC17ijFCePZKYVjNrHf/Bmjz7FaOI41kxueRhwLNIcQ2gmBqDR5W4TS2
# htRJYyZAs7jfJmbDtTcUOMhEl1OWlx/FnvcQbot5VPzaUwiT6Nie8l6PZjoQsuxi
# asuSAmxKIQdsHnJ5QokqwdyqXi1FZDtETVvbXfDsofzTta4en2qf48hzEZwUvbkz
# 5smt890nVAK7kz2crrzN3hpnfFuftp/rXLWTvxPQcfWXiEuIUd2Gg7eR8QtyKtJD
# U8+PDwECkzoaJjbGCKqx9ESgFJzzrXNwhhX6Rc8g2EU/+63mmqWeCF/kJOFg2eJw
# 7au/abESgq3EazyD1VlL+HaX+MBHGzQmHtvOm3Ql4wVTN3Wq8X8bCR68qiF5rFas
# m4RxF6zajZeSHC/qS5336/4aMDqsV6O86RlPPCYGJOPtf2MbKO7XJJeL/UQN0c3u
# ix5RMTo66dbATxPUFEG5Ph4PHzGjUbEO7D35LuEBiiG8YrlMROkGl3fBQl9bWbgw
# 9CIUQbwq5cTaExlfEpMdSoydJolUTQD5ELKGz1TJahTidd20wlwi5Bk36XImzsH4
# Ys15iXRfAjCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZI
# hvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# MjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAy
# MDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoIC
# AQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25Phdg
# M/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPF
# dvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6
# GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBp
# Dco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50Zu
# yjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3E
# XzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0
# lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1q
# GFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ
# +QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PA
# PBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkw
# EgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxG
# NSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARV
# MFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAK
# BggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG
# 9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0x
# M7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmC
# VgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449
# xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wM
# nosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDS
# PeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2d
# Y3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxn
# GSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+Crvs
# QWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokL
# jzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL
# 6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggNN
# MIICNQIBATCB+aGB0aSBzjCByzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEn
# MCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjkyMDAtMDVFMC1EOTQ3MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQB8
# 762rPTQd7InDCQdb1kgFKQkCRKCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBCwUAAgUA7RtdyjAiGA8yMDI2MDEyMTE0MTQz
# NFoYDzIwMjYwMTIyMTQxNDM0WjB0MDoGCisGAQQBhFkKBAExLDAqMAoCBQDtG13K
# AgEAMAcCAQACAgGKMAcCAQACAhU7MAoCBQDtHK9KAgEAMDYGCisGAQQBhFkKBAIx
# KDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZI
# hvcNAQELBQADggEBADhUIPpuGa1ZFRhKOj2NilEvGP9sZNifvF4QL73EzKGlJ+Fv
# 3xuVlQ1clZ74abthgOS+KyEcLO5gEGsk/FW9U+d4OqSapXrI0UmNc0XPgpN/KhgY
# opGIk5kGLYhvMtsuNoEjLN+hM3mOewt7OeMEcAhyU1CtfjrAvqDSX7h14xe0e0iz
# PSa/7+DXeRZYTWDs0RnUZT57f/pWPbKCpzxr0pHRTQNupgqXznFwmz+pNKWnJLZd
# V3DaV54gmrLOrbKoVM/iNVlJDkLR+nGyxpTTryl3O5K+wGZ+PgM8YrMd4fQ5F8TP
# LsX5sSJpaYhEu+EcqWws8iW9iNgogX9tO2OjHD8xggQNMIIECQIBATCBkzB8MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAgkIB+D5XIzmVQABAAACCTAN
# BglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8G
# CSqGSIb3DQEJBDEiBCAGGAVs1AM9E6rVEyyxiBx+JM89wfuUs1lQXnG0jZYimTCB
# +gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIGgbLB7IvfQCLmUOUZhjdUqK8bik
# fB6ZVVdoTjNwhRM+MIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIw
# MTACEzMAAAIJCAfg+VyM5lUAAQAAAgkwIgQgrur+PRUyddnIbOn85bd/Dmjp+J/R
# vH/UO30UZWC7AxowDQYJKoZIhvcNAQELBQAEggIAJrWeTfbVAimRIQrp8W6YfbUi
# xsUrfAf1xlwAthCPrzZfVJG1ZWTlAQKMfocea/EtPFRvrKug5MZcZgqIMP7P4fR7
# Mp8YczdgZK8+eVhIHNoY3TK3OBIYfyMQyuP1lbn8mNFHjVMrn445Z8EqHNbaWHV+
# W+ndSm2U35o7jFvaPnUUSTPTAK9eo/L7JpiEenL+mKmupknom4chpSj8sjI9A/E+
# f0XVLl56DZMI2tCccah0KCFyqsf421rxVLOetchVHmeQv0k3wgN3lZIoDEP/6N5g
# VDXzeTUMKgx/ZwlhO8K2sV/Gzg761EATUZZrc6g5Bct8LkoXbiArJiG+m9qX/w8d
# Y0Ajlrq/phDuh9yLU9aa2sx+YzBW7YNdUC1ySYK7j/Oz9b96bxT7WyAEIkv0Dqc1
# 5+DtdEt1AFQmxRfseGpcY1SFIuKe26l3swPhpt+HvyQZyRiRx+E4HqxqruNB36l1
# rXKSR1gweKUUHsvr1CmYEuR5D9uTRc1H+PnNHCrQYhQeclFzu4QYH2ika5ewClXu
# 3iCQzuEllR9lhMj6rTGypvgSy1HINj9ie3pGopZuNLPJ5FG2KMNWzhOj5xZh8RqH
# /tokJKNnUshlPSYgOdv7DFvksabOST8x5JiyTVggNUEdguZ/62wOSwZHOiebDu99
# PMq1R/MtyLk9cPSswyk=
# SIG # End signature block
